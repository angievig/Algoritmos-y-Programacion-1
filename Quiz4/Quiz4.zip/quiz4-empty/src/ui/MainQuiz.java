package ui;

import java.util.Scanner;

import model.Duck;
import model.Human;

public class MainQuiz {
	
	private Scanner sc;
	
	public MainQuiz() {
		sc= new Scanner(System.in);
	}

	public static void main(String[] args) {
		
		MainQuiz main= new MainQuiz();
		
		main.createObjects();
		

	}

	private void createObjects() {
		Human petro = new Human(30, "Gustavo");
		
		Duck don = new Duck(10, 50.4);
		
		
		System.out.println(petro.makeSound());
		System.out.println(don.makeSound());
		
		System.out.println("Funciona!!");
		
	}

}
