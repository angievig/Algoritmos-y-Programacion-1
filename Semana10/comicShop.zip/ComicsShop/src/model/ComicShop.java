package model;
/**
 * Clase controladora del proyecto comicsShop.
 * @author angievig
 * @version 1.0
 * @since April 2022
 */

public class ComicShop {
	private String nit;
	private double totalSales;
	private double totalTaxes;
	
	

	
	
	public ComicShop(String nit) {
		this.nit = nit;
		this.totalSales = 0;
		this.totalTaxes = 0;
	}


	
	
	public String toString() {
		int vendidos=0;

		return "**** Datos de la tienda ****\n" + 
		"nombre del dueño: " + nit + "\n" +
		"cantidad de dinero en caja: " + totalSales + "\n" +
		"cantidad de productos vendidos " + vendidos + "\n" ;		
	}



}
