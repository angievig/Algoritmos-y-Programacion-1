package model;
public class Child{

	private String name;
	private String lName;
	private String wish;
	private Location location;

	public Child(String pname, 
		String plName,
		String pwish,
		Location loc){

		name= pname;
		lName= plName;
		wish= pwish;
		location= loc;
	}

	public String toString(){
		return name + " " + lName;
	}

}