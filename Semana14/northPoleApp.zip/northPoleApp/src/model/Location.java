package model;
public class Location{
	private String address;
	private String country;
	private String city;

	public Location(String address,
		String country,
		String city){
		this.address= address;
		this.country= country;
		this.city = city;
	}

	public String toString(){

		return address + " " + city + " " + country;
	}
}