package model;
import java.util.ArrayList;

public class NorthPoleController{

	private ArrayList<Child> naugthy;
	private ArrayList<Child> good;

	public NorthPoleController(){

		naugthy= new ArrayList<Child>();
		good= new ArrayList<Child>();
	}

	public void addChild(String name, 
		String lName,
		String wish,
		String address,
		String country,
		String city
		){

	}

}